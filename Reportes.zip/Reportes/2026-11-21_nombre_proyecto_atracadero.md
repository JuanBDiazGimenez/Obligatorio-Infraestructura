# Nombre del proyecto de Parte 4

21/11/2026. A pedido de Fede se quitó su nombre del proyecto Docker de Parte 4 y se uniformaron también los reportes, con autorización explícita para modificar esas referencias anteriores.

## Cambios

- Fede/Parte 4/compose.yaml: proyecto atracadero e imagen Ada atracadero-ada:local en los cuatro servicios Ada.
- Fede/Parte 4/verificar.py: actualización del nombre en el comentario inicial; no cambia la lógica del verificador.
- Fede/Parte 4/README.md: nombres del proyecto y de la imagen expresados de forma explícita.
- Reporte 2026-11-21_implementacion_parte4_Fede.md: referencias al proyecto y la imagen actualizadas. Se conserva el resto de lo registrado; no se presenta una nueva ejecución funcional.

No se modificaron fuentes Ada, mensajes, claves Redis, puerto 6739, dependencias, condiciones de arranque ni evidencia previa. Rama Fede; sin operaciones de historial.

## Verificación realizada

Docker Compose config --quiet con el archivo de Parte 4 terminó correctamente. config --images mostró atracadero-ada:local para los cuatro servicios Ada y redis:7.4-alpine para Redis. docker ps -a, filtrado por la etiqueta del proyecto anterior, no devolvió contenedores. El primer intento de consultar el motor fue rechazado por permisos del entorno; la consulta de solo lectura se repitió con autorización y fue correcta.

No se recompiló ni se levantó la simulación. El cambio se limita a nombres de recursos Docker y textos: la comunicación interna sigue resolviendo el servicio redis y usando el protocolo previamente comprobado. Para el próximo arranque se sigue el README: docker compose build crea la imagen con su nombre actual antes de docker compose up. La imagen previa no se eliminó ni se hizo limpieza global.

## Fuentes y alcance

Letra Infraestructura Obligatorio Agosto 2026 (1).pdf, páginas 11-13: no prescribe un nombre de proyecto ni de imagen. La elección atracadero responde al recurso del ejercicio y al pedido actual del usuario. No se incorpora un mecanismo o biblioteca nuevos respecto de la revisión previa. La uniformidad de nombres no exige repetir los escenarios funcionales; la validación se concentra en la configuración afectada.

Uso de IA: Codex, GPT-6 según contexto de sesión, para cambiar referencias y verificar la configuración. No se atribuye una nueva ejecución funcional ni revisión humana.
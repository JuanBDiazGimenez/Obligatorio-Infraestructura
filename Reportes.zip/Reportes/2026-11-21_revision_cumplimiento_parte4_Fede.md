# Revisión de cumplimiento de Parte 4

Fecha: 21/11/2026. Alcance: revisión por lectura de Fede/Parte 4, sin modificar código ni repetir compilaciones o simulaciones. Rama consultada: Fede. Estado inicial: Fede/Parte 4 sin seguimiento; se preservó el trabajo existente.

## Conclusión

No se identificaron defectos funcionales ni requisitos de comportamiento pendientes respecto de la parte 4, páginas 11-13 de Infraestructura Obligatorio Agosto 2026 (1).pdf. La implementación puede considerarse terminada dentro del alcance acordado. La preparación de la documentación general de entrega en PDF y la revisión del equipo quedan para la etapa final ya acordada; el README actual es una guía de trabajo.

## Contraste con la letra

- Independencia y concurrencia: compose.yaml declara barco1, barco2 y barco3 como contenedores separados, cada uno ejecutando /app/barco con un identificador diferente. Comparten un ejecutable, pero son procesos independientes, no tasks de un único programa. Coordinador también es Ada; Redis transporta mensajes.
- Ciclo continuo: barco.adb sortea navegación y ocupación entre 1 y 3 segundos con Discrete_Random, solicita, espera AUTORIZADO, ocupa, informa LIBERAR y repite. La letra no prescribe un intervalo concreto.
- Exclusión: solo coordinador.adb modifica Ocupante y Estados. Reserva el lugar antes de enviar el permiso individual y no vuelve a autorizar hasta procesar LIBERAR del ocupante. Cada barco espera su permiso antes de entrar y envía la liberación después de salir.
- Solicitudes cercanas: RPUSH incorpora eventos a una lista común; el único coordinador los consume y guarda los pendientes sin bloquearse esperando la liberación dentro de una solicitud. La lista local circular atiende FIFO según llegada de mensajes a Redis, no según el orden visual de las consolas. FIFO es una elección del equipo, no una exigencia de la letra.
- Progreso: con tres barcos e identificadores únicos hay como máximo una solicitud pendiente por barco. La cola tiene capacidad suficiente. Tras una liberación se autoriza al primer pendiente; quien espera no depende de ganar repetidamente una carrera por un booleano. LPOP con pausa de 100 ms agrega latencia de consulta, pero no altera la reserva ni el orden.
- Arranque: Redis debe estar saludable; Preparar limpia las claves del proyecto y establece puerto:listo antes de admitir barcos. Se evita consumir un permiso anterior en un arranque completo. Se mantiene el alcance de una instancia del coordinador y reinicio del conjunto completo.
- Entregables técnicos: están las fuentes, Dockerfile, compose.yaml, instrucciones y explicación en README.md, verificador y evidencia textual. La conversión y selección final para la entrega no se hizo en esta revisión.

## Fuentes y relación con el curso

La letra, páginas 11-13, fija los requisitos y permite investigar la comunicación e infraestructura. Se contrastó directamente ese texto con los archivos. Como antecedentes de curso ya consultados y registrados en el reporte de implementación: laboratorio 8, voting-app.zip, Vote con RPUSH y Worker con ListLeftPopAsync y pausa de 100 ms; transcripción del 17/11, líneas 21-22 y 442-445, Redis para mensajes; IntroduccionDockerCompose (1) (1).pdf y apuntes del 17/11 para servicios y Compose. El protocolo de permisos, el coordinador y la adaptación desde Ada son decisiones propias. GNAT.Expect y Discrete_Random son las bibliotecas externas ya investigadas y acordadas, no se presentan como implementaciones docentes.

## Evidencia y límites de esta revisión

Se leyeron coordinador.adb, barco.adb, mensajeria.adb, README.md, compose.yaml, Dockerfile y verificar.py; también los cinco archivos de evidencia y el reporte previo 2026-11-21_implementacion_parte4_Fede.md. Se consultaron git status --short y git branch --show-current. La extracción del PDF se repitió con sustitución de caracteres para resolver un error de codificación de la consola; eso no afecta el documento ni la solución.

La evidencia real conservada muestra varios ciclos por barco: el log del coordinador registra 4 liberaciones del barco 1, 3 del barco 2 y 5 del barco 3. Entre cada autorización y la siguiente aparece la liberación del ocupante. solicitudes_juntas.txt muestra solicitudes 2,3,1 y autorizaciones en ese mismo orden, intercaladas con las liberaciones. Ese segundo archivo corresponde a un escenario dirigido de mensajes, no a otra ejecución de tres barcos reales.

No se ejecutaron Docker, GNAT ni verificar.py en esta instancia. La compilación y las pruebas previas constan en el reporte de implementación; no se atribuyen a esta revisión. Los fragmentos de logs no prueban todos los entrelazados posibles: la conclusión se apoya también en revisar el estado único y el orden reserva/permiso/salida/liberación. Los logs de contenedores distintos se capturaron en momentos diferentes y no se usan para inferir un orden global por su posición visual.

No se encontró motivo para cambiar código o ampliar pruebas. No se añadieron requisitos de recuperación ante fallos o reinicios parciales. No se modificaron reportes anteriores, ramas, historial ni servicios ajenos.

Uso de IA: Codex, modelo GPT-6 según contexto de sesión, para lectura, contraste de requisitos, razonamiento sobre sincronización y este reporte. La revisión humana y comprensión del equipo no se dan por realizadas.
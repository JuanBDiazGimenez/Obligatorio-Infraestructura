# PDF comparativo de Parte 3

Fecha: 21/11/2026. Se genero Fede/Comparacion_Parte_3.pdf, una pagina, por solicitud de Fede para discutir las versiones con su grupo. Se compararon mediante difflib los archivos actuales torneo.adb y verificar.py de Parte 3 y Parte 3 v2.

El PDF contiene solo diferencias: sorteos directos frente a funciones auxiliares, implicacion al leer, constante de escala temporal, metodo de reduccion de tiempos para pruebas y variantes de defensa adicionales de la v2. No se incluye una lista de similitudes ni se recomienda una version.

Generacion con ReportLab en Python del runtime provisto; render con pypdfium2. Confirmada una pagina e inspeccion visual: tabla legible, sin recortes ni superposiciones. No se recompilaron programas porque solo se creo el documento; las pruebas anteriores no se presentan como nuevas. No se modificaron los archivos comparados ni se hicieron commits. Se retiro solamente el PNG de revision y las carpetas temporales vacias creadas para este PDF.

Uso de IA: Codex, GPT-6 segun contexto; comparacion de fuentes y redaccion/maquetacion. Sin revision humana atribuida.

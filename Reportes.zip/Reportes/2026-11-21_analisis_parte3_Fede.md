# Analisis de Parte 3: torneo de padel
Fecha: 21/11/2026. Solo analisis solicitado; sin implementar ni compilar. Rama Fede, estado inicial sin cambios pendientes. Fede/Parte 3 existe y esta vacia; sera el destino de la implementacion.

## Requisitos y fuentes
Letra Infraestructura Obligatorio Agosto 2026 (1).pdf, paginas 9-11, revisadas por extraccion: 16 parejas, 8 partidos definidos desde el comienzo, 3 canchas independientes implementadas como tasks, una task Coordinador, solicitud y resultado mediante citas, duracion aleatoria no mayor a 4 segundos, ganador aleatorio entre las dos parejas, sin asignaciones repetidas, sin dos partidos a la vez por cancha, salida con asignaciones y resultados y terminacion tras finalizar los 8 partidos. No se exige generar rondas posteriores ni un cuadro eliminatorio.
Material de clase/8. ADA (1) (1).pdf: diapositiva 22 explica entry/accept y que quien llama espera hasta completar la cita; 27-28 explican select para varias entradas; 33 y 45 separan pedir/devolver del trabajo concurrente; 37 explica task type. Esta es la base docente; el protocolo de partidos propuesto es una adaptacion propia.
Apuntes/11-09 Lenguaje Ada Concurrente.md, secciones 4-6: tareas, citas y select. Apuntes/11-10 Programacion en Ada.md, secciones 5-6: espera implicita de tareas, bloqueos por accept no atendido y tipos de tareas. Son apuntes de apoyo.
Transcripciones/Infra 09-29.txt, lineas 275-304: presentacion de los requisitos de la parte 3, coherentes con el PDF.

## Propuesta para discutir
Un Coordinador conserva la lista de partidos, proximo pendiente, resultados y estado de cada cancha. Tres instancias de un mismo task type Cancha solicitan trabajo, juegan fuera de la cita, informan resultado por otra cita y vuelven a solicitar. Dos entradas del coordinador: Solicitar_Partido e Informar_Resultado; select permite atender cualquiera. Solicitar devuelve un partido o indica que no hay mas pendientes. La duracion de juego no se ejecuta dentro del accept, para que el Coordinador pueda seguir atendiendo otras canchas.
Asignacion de parejas propuesta: partido 1 parejas 1 y 2, partido 2 parejas 3 y 4, hasta partido 8 parejas 15 y 16. Son datos iniciales de esta propuesta, no una obligacion de nombres fijada por la letra.

## Terminacion
Distinguir asignados de terminados. Al entregar el octavo partido todavia puede haber hasta tres partidos en curso. Las canchas libres sin pendientes reciben fin y terminan; las que estan jugando informan su resultado antes de solicitar nuevamente. El Coordinador debe permanecer disponible para esos resultados y para responder las solicitudes finales de las tres canchas. Puede terminar tras ocho resultados y tres respuestas de fin, evitando dejar una cancha llamando a una task ya finalizada. Son contadores de estado diferentes, no trabajo ficticio ni nuevas rondas.

## Verificacion prevista (no ejecutada)
Compilar en el entorno que se confirme para Ada; comprobar disponibilidad de GNAT antes de prometer compilacion. Repetir ejecuciones para comprobar 8 asignaciones y 8 resultados unicos, correspondencia entre cancha y partido, ganador perteneciente al encuentro, no mas de un partido por cancha, hasta tres simultaneos, informe antes de nueva solicitud y finalizacion de todas las tasks. Incorporar comentarios didacticos sobre entry, accept, select y terminacion durante el desarrollo, conforme a AGENTS.md. No se iniciaron contenedores ni procesos de simulacion para este analisis.

## Uso de IA
Codex, modelo GPT-6 segun contexto: lectura de fuentes y propuesta de diseno para discutir. No se atribuye implementacion ni verificacion ejecutada; revision humana pendiente. Sin PDF ni documentacion de entrega.

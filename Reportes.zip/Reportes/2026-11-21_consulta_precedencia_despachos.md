# Consulta: esperar despachos anteriores concretos

Fecha: 21/11/2026. Sin modificaciones de codigo ni nuevas ejecuciones de la simulacion.

## Consulta y conclusion
Fede consulta si POSIX permite que un paquete normal espere por los prioritarios que ya estaban en curso al comenzar su turno, excluyendo prioritarios posteriores, y si ese mecanismo fue visto en clase.
Es construible con semaforos POSIX y estado compartido protegido. No existe una operacion de semaforo que interprete categorias o identifique trabajos por si misma. Una propuesta registra bajo exclusion los IDs concretos de los trabajos previos de los que depende el normal. Al terminar cada trabajo se actualizan exclusivamente las esperas que dependian de ese ID; cuando no queda ninguna dependencia se hace post sobre el semaforo de ese normal, inicialmente en cero. El normal libera el mutex antes de esperar. Nuevos trabajos en el mismo hilo no se incorporan a la espera. Es necesaria la identidad del trabajo, no solo la identidad del despachador ni un contador de todos los prioritarios activos.
Ejemplo: normal N registra A y B. A termina, el mismo despachador toma C, B termina. N queda habilitado sin esperar C. El registro y la finalizacion deben coordinarse con el mismo mutex para no perder notificaciones. No se implemento ni verifico esta propuesta.
Esta espera por predecesores no garantiza por si sola la regla de tres en el orden de finalizacion: C y otros posteriores todavia podrian terminar antes que N. Exigir esa interpretacion implica coordinar tambien las finalizaciones respecto al turno de N. No se presenta el mecanismo como correccion completa del requisito ambiguo.

## Fuentes revisadas
- Apuntes/10-12 Semaforos y Procesos.md, seccion 3: grafos de precedencia con semaforos por arista, inicializados en cero, P antes del sucesor y V al terminar el predecesor.
- Transcripciones/Infra 10-12.txt, pasaje alrededor de lineas 910-970: el docente compara con fork/join y explica asignar un semaforo por cada arista del grafo.
- Apuntes/10-20 Hilos y Semaforos.md, secciones 3-4: orden por sem_wait/sem_post y convergencia de dos tareas previas en otra tarea.
- Transcripciones/Infra 10-20.txt, pasaje alrededor de lineas 1235-1298: el docente explica usar semaforo inicialmente en cero para precedencia y posteriormente propone un grafo en C.
- Apuntes/10-19 Problemas de Concurrencia.md: contador de lectores y aplazamiento de escritores si siguen llegando lectores; ilustra el problema de esperar a que desaparezca una clase abierta de trabajos.
Los apuntes son un apoyo; se contrastaron las explicaciones de precedencia con la transcripcion docente. La seleccion dinamica de dependencias por paquete es una adaptacion nuestra: no se encontro ese ejemplo exacto entre los pasajes revisados.
- Fuente tecnica externa primaria: Oracle Multithreaded Programming Guide, Semaphores, https://docs.oracle.com/cd/E19683-01/806-6867/sync-27385/index.html : sem_wait y sem_post corresponden a P y V. Los enlaces de Open Group consultados devolvieron HTTP 403, por lo que no se atribuye una lectura exitosa de esas paginas.

## Verificacion y pendientes
Revision de fuentes y razonamiento conceptual solamente. No se modifico main.c ni los verificadores. No se compilo ni ejecuto una alternativa. Si se decide cambiar la politica, primero resolver la interpretacion del requisito y despues implementar y verificar las nuevas dependencias y la ausencia de bloqueo.

## Uso de IA
Codex (modelo GPT-6 segun contexto): busqueda local, consulta de documentacion tecnica y explicacion conceptual. Sin revision humana atribuida ni implementacion docente inventada.

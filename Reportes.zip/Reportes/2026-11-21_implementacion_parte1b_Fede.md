# Parte 1.b - Propuesta de Fede (21/11/2026)

## Alcance y archivos
Trabajo en rama Fede, ya seleccionada por el usuario; sin cambios de rama, commits ni otras operaciones de historial. Se agregaron Fede/Parte 1/don_drones.sh, flota.csv (copia exacta inicial), implementacion_parte1b.md y su PDF de tres paginas. No se modificaron archivos de Parte 1 original ni de la parte a. usuarios.csv se genera durante el primer uso con admin/admin y conserva nuevos registros.

## Fuentes y decisiones
Letra, paginas 3-5, consultada por extraccion con pypdf. Apuntes del 08/09, seccion 3: funciones, read, variables, if, while y operadores numericos. Transcripcion 29/09, seccion Parte 1: el docente admite investigacion adicional a lo visto. Laboratorios Infra (1).pdf, paginas 13-16: Bash, funciones, entrada y archivos; el titulo dice Solucion laboratorio 1 pero su autoria no fue verificada y no se atribuye como oficial.
La transcripcion contiene 90 por ciento al leer el reporte, mientras el PDF y el script indican 20. Se mantiene el requisito escrito del PDF; no se interpreta la transcripcion como una aclaracion oficial.
Funciones por operacion, usuarios en CSV simple, ID por maximo correlativo de categoria, busqueda exacta y reescritura por temporal son decisiones de esta propuesta. Se conserva el bucle sin pipeline de Fede y comparacion -gt 20 de 1.a. Critica es -lt 20. Se validan campos no vacios, delimitadores, categorias, disponibilidad y bateria entera entre 0 y 100. La documentacion explica funciones, flujo, decisiones, dependencias, ejemplo y autoria.

## Verificaciones ejecutadas
Windows/PowerShell con Git Bash GNU Bash 5.3.9. Ejecuciones mediante subprocess de Python, exclusivamente como lanzador de pruebas, sobre copias temporales con limpieza automatica. La implementacion es solamente Bash y comandos de sistema.
- bash -n sobre don_drones.sh: correcto.
- Inicio con admin/admin; registro persistente; duplicados; login correcto e incorrecto; cierre de sesion; salida; opciones invalidas y EOF: correctos.
- Alta de Cargo CAR-006 con modelo de espacios, bateria 08 normalizada a 8 y disponibilidad normalizada a Si. Rechazo de categoria invalida, modelos vacios o con coma, usuario/clave vacios y con coma, baterias negativas, no numericas y mayores de 100, disponibilidad invalida: correctos.
- Asignacion RAC-002 (5) rechazada; COO-003 (88) persistida como No; CAR-004 ocupado rechazado; ID inexistente y .* no tratados como patrones: correctos.
- Actualizacion de CAR-006 a 20/No y luego 21/Si; asignacion posterior y CSV persistente: correctos. Nuevo inicio mantiene usuario y genera CAR-007.
- Pruebas separadas con 0,19,20,21,100: solo 21 y 100 se asignan. Flota solo con encabezado informa 0 y alta inicial genera SCO-001.
- Ejemplo completo de la documentacion ejecutado: registro fede/clave123, alta Cargo con 8, reporte de 8 criticos, rechazo de asignacion, actualizacion a 80/Si, asignacion a No, reporte de 7, logout, login y salida. Reinicio conserva los datos.
- Siguientes IDs de las cinco categorias verificados: CAR-007 tras las altas previas, SCO-004, HEA-005, COO-005, RAC-005.
- Ejecucion desde una carpeta distinta encuentra los datos junto al script. El flota.csv entregado sigue siendo copia exacta del original; no hay usuarios de prueba en la carpeta final. Script con LF.
- PDF generado con reportlab; renderizado de las tres paginas con pypdfium2; inspeccion visual conjunta sin recortes ni texto superpuesto.

## Problemas encontrados y limites
La primera prueba enviaba CRLF por traduccion de stdin en Windows, impidiendo reconocer las opciones. Se corrigio el lanzador para enviar bytes LF; no se altero la logica para ocultar un fallo. Python del sistema no incluia bibliotecas PDF: se uso el runtime provisto. PyMuPDF no estaba disponible en ese runtime; se renderizo con pypdfium2.
Se verifico en Git Bash, no en GNU/Linux. Datos iniciales validos, CSV simple sin comas en campos y una instancia del programa a la vez. Contrasenas en texto simple para el ejercicio local. No se agregaron mecanismos de concurrencia, recuperacion de archivos editados manualmente ni dependencias de otro lenguaje al sistema. La revision y comprension humana por el equipo sigue pendiente; no se afirma que la entrega global este cerrada.

## Uso de IA
Codex, modelo GPT-6 segun el contexto de sesion: implementacion, analisis, documentacion y generacion/ejecucion de pruebas. Las decisiones son una propuesta para revision de Fede y puesta en comun; no se inventan revisiones de integrantes.

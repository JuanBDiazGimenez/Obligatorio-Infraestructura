# PDF comparativo de Parte 2
Fecha: 21/11/2026. Se compararon con difflib main.c, pruebas_prioridad.c y verificar.py de Fede/Parte 2 y Parte 2 v2. Se genero Fede/Comparacion_Parte_2.pdf, una pagina, con el formato del comparativo de Parte 3 para discusion del grupo.
Diferencias incluidas: mensajes de inicio, estado visible de prioridad, registro bajo mutex_finales, parametro de despachador, salida normal de 1201 frente a 1501 lineas y verificaciones adicionales. Se distingue expresamente el orden de inicio del de finalizacion. No se recompilo ni modifico la simulacion.
Generado con ReportLab del runtime provisto, renderizado con pypdfium2 e inspeccionado visualmente: una pagina legible sin recortes ni superposiciones. Se retiro solo el render temporal y sus carpetas vacias. Sin commits.
Uso de IA: Codex, GPT-6 segun contexto, para comparacion de fuentes y redaccion/maquetacion. Sin revision humana atribuida.

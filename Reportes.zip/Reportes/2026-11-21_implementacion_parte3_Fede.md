# Parte 3: implementacion nueva del torneo de padel
Fecha: 21/11/2026. Rama Fede. Se partio de Fede/Parte 3 vacia, comprobada antes de editar. Usuario autoriza Discrete_Random y solicita explicar su uso en un Markdown independiente y en este reporte. Sin commits, cambios de rama, PDFs ni documentacion de entrega general.

## Archivos y fuentes
- Fede/Parte 3/torneo.adb: programa Ada nuevo.
- Fede/Parte 3/Discrete_Random.md: explicacion independiente, sencilla, de aleatoriedad y cambios posibles en defensa.
- Fede/Parte 3/verificar.py: verificador de ejecuciones en copias temporales, no dependencia del programa.
Fuentes: letra Infraestructura Obligatorio Agosto 2026 (1).pdf, paginas 9-11 (requisitos de torneo) y 14 (bibliotecas no dadas en clase admitidas con total solvencia). Material de clase/8. ADA (1) (1).pdf, diapositivas 11,14,18 (paquetes), 22 (rendezvous), 27 (select), 37 (task type) y 45 (trabajo fuera de la cita). Apuntes 09/11, secciones 4-6 y 10/11, secciones 5-6: tareas, citas, seleccion y finalizacion implicita. La transcripcion del 29/09, lineas 275-304, presenta los requisitos. Las clases nuevas 16/11 y 17/11 fueron revisadas en el turno anterior y no modifican este diseno.
Fuente tecnica externa: manual de referencia Ada A.5.2, https://www.adaic.org/resources/add_content/standards/12rm/html/RM-A-5-2.html . Respalda el paquete estandar, instanciacion por subtipo, Generator, Random, Reset y advertencias sobre generadores compartidos e inicializaciones proximas. No se afirma que ese paquete concreto se enseno en clase. Su eleccion fue autorizada por Fede.

## Diseno y flujo de una ejecucion
El torneo define ocho encuentros desde el comienzo: parejas 1/2, 3/4, hasta 15/16. Esos emparejamientos son datos de esta propuesta; no se generan nuevas rondas.
Una task Coordinador posee el siguiente numero pendiente, resultados, partido por cancha y registro de cierre. Tres instancias de task type Cancha se identifican con discriminantes 1,2,3. El discriminante es el identificador fijado al declarar cada instancia, no una variable global compartida.
Una cancha llama Solicitar_Partido; el Coordinador acepta, reserva el siguiente encuentro y lo devuelve mediante out, o devuelve cero para indicar fin. Quien llama espera hasta completar el accept. La asignacion cambia solo en el Coordinador y por eso no se duplica.
La cancha obtiene una duracion, imprime inicio y hace delay fuera de la cita: las otras canchas y el Coordinador siguen trabajando. Al terminar determina el ganador, imprime y llama Informar_Resultado. El Coordinador registra el resultado; solo al terminar esa cita la cancha vuelve a pedir otro encuentro. Cada cancha tiene un solo flujo secuencial y nunca juega dos partidos simultaneos.
El select atiende solicitud o resultado, sin imponer una alternancia que deje bloqueado al emisor equivocado. No se agregaron semaforos ni objetos protegidos: la sincronizacion utiliza tasks y citas.
En_Juego y Ganadores permiten verificar correspondencia y unicidad con pragma Assert. Estas comprobaciones no sincronizan; se activan con -gnata. Son comprobaciones de consistencia propias, no una construccion docente atribuida. Los subtype restringen rangos; record agrupa las parejas de un partido; Integer'Image y atributos de subtipos convierten identificadores a texto.

## Cierre
Asignar ocho partidos no significa terminar ocho partidos. El Coordinador permanece disponible mientras no haya respondido fin a las tres canchas. Una cancha recibe fin solo estando libre, despues de informar su ultimo resultado. Por lo tanto, al cerrar las tres ya se recibieron ocho resultados; se comprueba con Assert.
El bloque declare contiene todas las tareas. Ada espera la terminacion de sus dependientes antes de salir de ese bloque; Torneo terminado se imprime despues. Asi ninguna cancha llama a un Coordinador ya finalizado, ni el main anuncia terminacion mientras queda una cancha ejecutando.
Los comentarios didacticos explican llamadas, esperas, select, estado propio y cierre. Se conservaron durante el desarrollo conforme a AGENTS.md; antes de la entrega final se revisaran los comentarios temporales.

## Verificacion ejecutada
Entorno mi_ubuntu existente, GNATMAKE 13.3.0 y Python 3, sin instalar paquetes. Carpeta propia /tmp/infra-fede-parte3-final-20261121.
Comandos:
- docker exec mi_ubuntu mkdir /tmp/infra-fede-parte3-final-20261121
- docker cp "Fede/Parte 3/." mi_ubuntu:/tmp/infra-fede-parte3-final-20261121/
- docker exec -w /tmp/infra-fede-parte3-final-20261121 mi_ubuntu gnatmake -gnat2012 -gnatwa -gnatwe -gnata -gnato torneo.adb
- docker exec mi_ubuntu python3 /tmp/infra-fede-parte3-final-20261121/verificar.py
Compilacion Ada 2012 con todas las advertencias, advertencias como errores, assertions y comprobaciones de desbordamiento: correcta, sin diagnosticos.
El verificador compila copias temporales; mantiene intacta la fuente entregada. En la copia rapida cambia Unidad_Tiempo de 1.0 a 0.01, conservando duraciones sorteadas 0-4 y todo el protocolo. En dos variantes sustituye exclusivamente las funciones Elegir_Duracion y Elegir_Ganador para devolver constantes.
Resultados:
- 20 ejecuciones rapidas correctas: ocho asignaciones y ocho resultados unicos, pareja ganadora perteneciente al partido, informe previo a nueva solicitud, cierre una vez por cancha, sin uso simultaneo de una cancha, anuncio final despues de cerrar todas las tareas.
- Se observaron hasta tres canchas jugando, 19 distribuciones de partidos entre canchas y todos los valores de duracion 0,1,2,3,4. No se exige que una distribucion concreta aparezca ni que todas las ejecuciones sean distintas.
- Variante sin azar, duracion cero y ganador siempre A: correcta.
- Variante sin azar, duracion cuatro y ganador siempre B, con unidad reducida solo en la copia de prueba: correcta. Tasks y citas sin modificaciones en ambas variantes.
- Dos ejecuciones con fuente original y segundos reales: correctas, ocho resultados y tres canchas cerradas en ambas; hasta tres canchas jugando. Duraciones observadas primera: 0,1,2,3; segunda: 0,3,4.
- git diff --check sin problemas. Solo Fede/Parte 3 aparece como nuevo en Git.
Una compilacion normal dentro de Linux puede realizarse con gnatmake -gnat2012 -gnata torneo.adb y luego ./torneo. No hace falta Python para compilar ni ejecutar la simulacion.

## Limites y pendientes
Las ejecuciones no cubren exhaustivamente todos los entrelazados; se complemento con razonamiento del protocolo y propiedad exclusiva del estado en el Coordinador. No se probaron fallos del runtime ni cancelaciones de tasks. La semilla temporal no garantiza secuencias diferentes entre generadores inicializados muy cerca: no se promete independencia estadistica que el manual no garantiza. Cada generador tiene estado separado, eliminando accesos concurrentes a ese mismo estado.
Queda revision humana del codigo para puesta en comun y defensa, y documentacion general de entrega al final. Se retiraron unicamente carpetas temporales de esta parte creadas por el asistente, incluyendo el borrador previo, sin tocar contenedores ni archivos ajenos.

## Uso de IA
Codex (modelo GPT-6 segun contexto de sesion): implementacion, explicaciones, pruebas y reporte. No se atribuye revision humana ni implementacion oficial del docente.

---
## Explicacion de Discrete_Random solicitada por Fede

# Discrete_Random y el azar del torneo

`Ada.Numerics.Discrete_Random` es un paquete de la biblioteca estándar de Ada
para generar valores **pseudoaleatorios discretos**, por ejemplo números enteros.
No es una biblioteca de terceros que tengamos que descargar por separado.

## Qué significa cada cosa

1. **Rango:** indica qué valores pueden salir. En el torneo usamos enteros entre
   **0 y 4** para la duración y entre **1 y 2** para elegir una de las dos parejas.
2. **Paquete genérico:** es una plantilla. Al instanciarla le indicamos el tipo y
   rango que necesitamos. Así obtenemos `Azar_Duracion` y `Azar_Ganador`.
3. **Generator:** es el objeto que conserva el estado de una secuencia. No es un
   número sorteado ni la semilla: guarda la información necesaria para obtener
   sucesivos valores.
4. **Reset:** inicializa ese estado. Sin semilla explícita usa una inicialización
   dependiente del tiempo. Con una semilla entera explícita se puede repetir la
   secuencia en la misma implementación, lo que sirve para pruebas.
5. **Random:** devuelve el siguiente valor del rango y avanza el estado del
   generador. Se llama cada vez que necesitamos otro sorteo; **no se hace Reset
   antes de cada llamada**.

Se dice pseudoaleatorio porque una secuencia depende de su estado inicial y de
un algoritmo. No es azar físico ni garantiza resultados diferentes en cada
llamada: dos partidos pueden durar lo mismo y puede ganar varias veces la primera
pareja. Tampoco se garantiza que dos Reset muy próximos den secuencias distintas.

## Cómo se usa en este programa

Cada cancha tiene dos generadores propios: uno para duración y otro para ganador.
Los inicializa una vez al comenzar. Antes de jugar llama a `Elegir_Duracion`;
después de la demora llama a `Elegir_Ganador`. El sorteo 1 significa la pareja A
del partido y el 2 la pareja B, no necesariamente las parejas globales 1 y 2.

Los generadores no se comparten entre canchas. Por eso no hace falta agregar un
semáforo ni una cita para protegerlos. El Coordinador sigue usando únicamente
tasks y rendezvous para asignar partidos y recibir resultados. El paquete no
decide qué cancha recibe cada partido ni sincroniza la ejecución.

## Si en la defensa piden eliminar el azar

**No hay que rehacer el torneo.** La política de elección está separada de su
coordinación mediante dos funciones pequeñas:

- Para que los partidos duren siempre dos segundos, `Elegir_Duracion` devolvería
  siempre 2, en lugar de pedir un valor a `Random`.
- Para que gane siempre la primera pareja, `Elegir_Ganador` devolvería siempre
  `Encuentro.Pareja_A`.
- Para aplicar otra regla, por ejemplo favorecer a la pareja de menor número,
  se cambiaría solamente la elección del ganador.

Las tasks, las citas, las asignaciones y el cierre no cambian. Si se retirara
completamente el paquete, también habría que quitar los generadores, sus Reset,
las instancias y los parámetros que ya no se usan. Esa es una limpieza localizada,
no una reescritura de la sincronización. Devolver valores fijos sería una variante
para la pregunta de defensa, no la entrega actual que pide aleatoriedad.

Con un generador propio también se podría separar la elección en estas funciones.
Cambiarlo por una regla fija sería igual de localizado; habría más código del
generador propio que explicar y eventualmente retirar. La facilidad para cambiar
depende de separar responsabilidades, no de que el generador sea propio o estándar.

## Justificación y fuentes

- La letra, `Infraestructura Obligatorio Agosto 2026 (1).pdf`, páginas 9–10,
  pide duración y ganador aleatorios. La rúbrica de la página 14 **no prohíbe**
  bibliotecas no dadas en clase: exige demostrar total solvencia en su utilización.
- `Material de clase/8. ADA (1) (1).pdf`, diapositivas 11 y 14, muestra el uso de
  `Ada.Text_IO` y `Ada.Integer_Text_IO`; la 18 explica paquetes. Esto respalda
  el uso de paquetes, pero **no demuestra que Discrete_Random se enseñara**.
- [Manual de referencia de Ada, A.5.2](https://www.adaic.org/resources/add_content/standards/12rm/html/RM-A-5-2.html):
  fuente externa para `Discrete_Random`, `Generator`, `Reset` y `Random`, y para la
  necesidad de sincronizar un generador si se compartiera entre tareas.

La elección de este paquete y de las dos funciones es una decisión de esta
implementación, no una solución atribuida al docente. Esta explicación se preparó
con asistencia de Codex (GPT-6 según el contexto de la sesión); el equipo debe
revisarla y poder explicar el uso concreto.

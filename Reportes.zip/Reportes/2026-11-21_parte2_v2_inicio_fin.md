# Parte 2 v2: inicio y finalizacion de despacho

Fecha: 21/11/2026. Rama Fede. Solicitud: modificar exclusivamente la copia Fede/Parte 2 v2 para observar inicio y fin de cada despacho, preservando la primera version.

## Cambios y criterio
- main.c: retirar_para_despacho recibe el ID del despachador. Imprime el inicio dentro de mutex_finales, despues de elegir y retirar el paquete, antes de liberar la exclusion. El mensaje incluye ID de trabajador, ID de paquete, prioridad, normales esperando al elegir (antes del retiro) y valor del contador de prioridad tras la eleccion.
- Se conserva el mensaje exigido al finalizar. No se modifican la politica de seleccion, las capacidades, los tiempos ni el total. La demora sigue fuera del mutex: los tres despachadores pueden trabajar en paralelo. El contador satura en tres si no hay normales; no representa una racha ilimitada.
- pruebas_prioridad.c: adaptacion de llamadas a la firma con ID.
- verificar.py: comprueba 300 pares inicio/fin, IDs, prioridad, orden de seleccion y contador, correspondencia del mismo despachador, ausencia de reutilizacion mientras este activo y superposicion de despachos. Contrasta los inicios contra las extracciones y estados de las colas cuando hay trazas. Ademas verifica la salida normal sin trazas, que ahora tiene 1501 lineas.

## Fuentes
Letra Infraestructura Obligatorio Agosto 2026 (1).pdf, paginas 7-8: 300 paquetes, actores, mensajes, tiempos y prioridad. Material de clase/6.  Semaforos Version Marzo (1).pdf, diapositivas 14-19: disponibilidad y exclusion de operaciones sobre buffers. Apuntes del 20/10, secciones 1 y 3: semaforos y precedencia. Estas fuentes fueron consultadas durante la implementacion y revision previa de esta misma parte. Registrar el inicio dentro de la seleccion es una adaptacion propia, no una solucion docente.
Se mantiene el criterio acordado en la conversacion: la regla de tres coordina el inicio por seleccion de cola; la finalizacion puede aparecer en distinto orden. Los nuevos mensajes permiten observar ese criterio, no cambian la ambiguedad de la letra ni garantizan una secuencia de finalizaciones.

## Verificacion ejecutada
Entorno autorizado: contenedor existente mi_ubuntu. Se copiaron solo los tres archivos v2 a /tmp/infra-fede-parte2-v2-20261121. Comandos:
- docker exec mi_ubuntu mkdir /tmp/infra-fede-parte2-v2-20261121
- docker cp "Fede/Parte 2 v2/." mi_ubuntu:/tmp/infra-fede-parte2-v2-20261121/
- docker exec mi_ubuntu python3 /tmp/infra-fede-parte2-v2-20261121/verificar.py
Resultados:
- Compilacion GCC con -std=c11 -Wall -Wextra -Wpedantic -Werror -pthread sin advertencias.
- Prueba dirigida de secuencia 3:1, FIFO, una sola cola, llegada tardia de normal y cierre: correcta.
- Doce semillas con unidad de tiempo reducida a 1 ms: 300 paquetes por etapa, FIFO, capacidades, prioridad y pares inicio/fin correctos. La cantidad de turnos normales forzados fue 26,22,22,25,18,21,14,8,10,16,11,17.
- AddressSanitizer y UndefinedBehaviorSanitizer: sin diagnosticos.
- Compilacion de version normal con tiempos por defecto: correcta. Ejecucion sin trazas pero con tiempos reducidos: exactamente 1501 lineas, 300 pares inicio/fin y hasta tres despachos simultaneos.
- Fede/Parte 2 comparada contra HEAD sin diferencias; git diff --check sin problemas.
No se repitio la simulacion larga con tiempos reales: el cambio afecta registro de inicio y verificacion, no el calculo de demoras; la primera version ya tuvo una ejecucion real completa. No se presentan pruebas rapidas como ejecuciones con tiempos reales. No hay prueba exhaustiva de todos los entrelazados.

## Estado y autoria
Version anterior intacta. Sin commits ni cambios de rama. Sin PDFs ni documentacion de entrega. Carpeta temporal propia retirada al terminar; no se instalaron paquetes ni se tocaron otros contenedores.
Codex, modelo GPT-6 segun contexto de sesion: implementacion del cambio, ajuste y ejecucion de pruebas y reporte. Revision humana y puesta en comun pendientes.

# Revisión de Parte 1.a — 21/11/2026

## Alcance y autoría
Revisión solicitada por Fede, sin modificar scripts, CSV ni documentos existentes. Fede aclaró que informe_parte1a.md corresponde a su compañera y parte1a_problema1_Fede.md complementa solamente la solución diferente del problema 1. Herramienta: Codex, modelo GPT-6 según contexto de sesión. Uso: lectura, análisis y ejecución de pruebas; no se atribuye revisión humana de estos resultados.

## Fuentes
- Letra: Infraestructura Obligatorio Agosto 2026 (1).pdf, páginas 3–5, consultadas en esta conversación: diagnóstico y corrección mínima en 1.a; existencia del dron es requisito adicional de 1.b.
- Transcripciones/Infra 09-29.txt, líneas 89–106: el docente pide diagnóstico y corrección de ambos problemas y admite investigar mecanismos no vistos directamente en clase.
- Apuntes/09-08 Infraestructura y Procesos en C.md, sección 3: read, condicionales, operadores numéricos y while. Son apuntes, no una solución oficial.
- Scripts y Markdown de Parte 1, comparados por lectura y diff. La adaptación con bloque y redirección pertenece a esta solución, no se atribuye al docente.

## Revisión
El original se conserva. El fix modifica únicamente el contexto del bucle contador y la comparación de batería. El bloque de llaves recibe el CSV por entrada estándar; el primer read consume el encabezado y el while actualiza el contador en el shell actual. Esto es una alternativa válida a la sustitución de procesos descrita por la compañera. El operador -gt sustituye la redirección accidental con > y compara enteros.
Los diagnósticos de ambos errores son correctos para el entorno normal de Bash. La afirmación general de que todo pipeline ejecuta cada componente en subshell admite excepciones como lastpipe; no invalida el caso probado.

## Verificación ejecutada
Windows, PowerShell, Git Bash GNU Bash 5.3.9 x86_64-pc-cygwin. Harness Python utilizado solamente para lanzar Bash y preparar copias temporales, sin sustituir lógica del ejercicio. Se ejecutaron bash script argumentos y se inspeccionaron códigos de salida, CSV y archivo 20. Cada caso partió de una copia nueva. Las copias temporales se retiraron automáticamente.
- Original, normalizado a LF para aislar lógica: bateria_critica produce 0; asignar RAC-002 produce éxito, cambia Si a No y crea archivo 20.
- Fix, copia LF: bateria_critica produce 7; RAC-002 (5 %) rechazado con exit 1 y CSV intacto; COO-003 (88 %) aceptado con exit 0 y persistido como No; CAR-004 ya ocupado rechazado con exit 1; no se crea archivo 20.
- Datos sintéticos de un dron: batería 0, 19 y 20 rechazadas; 21 y 100 aceptadas y persistidas como No. Se mantiene >20 del original; batería crítica sigue siendo <20. No se cambia el umbral por inferencia.
- Fix con bytes originales CRLF: bateria_critica produce 7 en este Git Bash. No se verificó en una distribución GNU/Linux: WSL solo ofrece docker-desktop y allí no se encontró Bash.
- Estado Git inicial: rama main, solamente AGENTS.md sin seguimiento; sin diferencias de trabajo en Parte 1.

## Observaciones y pendientes
1. Ambos scripts tienen CRLF: original 47 líneas, fix 50 líneas. El CSV tiene LF. El informe de la compañera afirma que el fix está en LF: esa afirmación no coincide con el archivo actual. Git Bash lo toleró en la prueba, pero conviene entregar el fix en LF y verificar ejecución directa en Linux. No se modificaron finales de línea.
2. El documento de Fede usa bash don_drones_manager.sh en el ejemplo de verificación aunque la solución está en don_drones_manager_fix.sh. El original actual devuelve 0. Debe aclararse qué archivo se probó o corregirse el nombre del ejemplo antes de entregar.
3. El informe principal explica sustitución de procesos y una tabla de tres líneas modificadas. Es coherente con la variante de la compañera; el complemento de Fede explica la variante efectivamente presente. Para entrega, dejar inequívoco qué variante acompaña al script, sin borrar autoría ni presentar el complemento como diagnóstico completo.
4. No se exige comprobar existencia del ID en 1.a: la letra lo agrega en 1.b. No se amplió el alcance.
5. No se ejecutó una prueba independiente de la variante de sustitución de procesos de la compañera; su validez se revisó por lectura.

Conclusión: lógica de 1.a correcta en los escenarios probados. Quedan ajustes de presentación, nombre del comando del complemento y formato de línea para cerrar la entrega. Ningún archivo existente fue editado.

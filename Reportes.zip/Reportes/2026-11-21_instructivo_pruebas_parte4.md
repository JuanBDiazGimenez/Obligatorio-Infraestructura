# Guía de ejecución y pruebas de Parte 4

Fecha: 21/11/2026. Pedido: PDF sencillo para que Fede y el grupo puedan ejecutar y probar Parte 4, similar a los instructivos anteriores. Rama consultada: Fede; inicialmente sin diferencias pendientes.

## Resultado

Se creó Fede/Parte 4/Instructivo_pruebas_Parte_4.pdf, de dos páginas. Página 1: requisitos de Docker Desktop con contenedores Linux, terminal PowerShell desde la raíz, preparación de imágenes, arranque, revisión de los cinco servicios, seguimiento de logs, señales de exclusión mutua y detención. Página 2: ejecución de verificar.py con Python 3 en el equipo, escenarios reales y dirigidos, mensajes esperados, revisión de evidencia, reemplazo de archivos al repetir y ayuda ante errores.

Se usan los nombres actuales atracadero y atracadero-ada:local. Se explica que GNAT se instala en la imagen de compilación, no en Windows; no se usa mi_ubuntu. Se distingue Ctrl+C al seguir logs de docker compose down. El caso dirigido 2,3,1 se identifica como mensajes de prueba, separado de los barcos reales. La guía explica que el verificador termina retirando el proyecto y que la simulación por sí sola es continua.

## Fuentes

Se contrastaron README.md, compose.yaml y verificar.py actuales de Fede/Parte 4. Se consultó el instructivo de Parte 3 como referencia de estilo. La letra Infraestructura Obligatorio Agosto 2026 (1).pdf, páginas 11-13, fundamenta instrucciones y evidencia, según la revisión ya realizada; no se cambió la implementación ni se incorporó un mecanismo del curso nuevo. Los comandos y resultados esperados se derivan de esos archivos.

## Verificación documental

Se utilizó la habilidad pdf y las dependencias del runtime de Codex: ReportLab para generar, pypdf para extraer texto y comprobar dos páginas, y Poppler pdftoppm para renderizar ambas páginas a PNG. Se inspeccionaron visualmente las dos: sin texto cortado, superposiciones ni caracteres defectuosos. Poppler informó avisos sobre fuentes de sustitución Symbol/ArialUnicode; las páginas renderizadas con Arial embebida y los comandos se visualizaron correctamente.

Se retiraron el script temporal y las dos imágenes, y sus directorios cuando quedaron vacíos. Solo se conserva el PDF final en Parte 4. No se ejecutaron Docker, compilación Ada ni el verificador funcional en esta instancia: se documentó el procedimiento existente, previamente probado. No se modificaron código, Compose, evidencia anterior ni reportes anteriores; sin commits ni cambios de rama.

Uso de IA: Codex, GPT-6 según contexto de sesión, para redactar la guía, producir el PDF y revisar su presentación. La lectura y prueba por el grupo quedan a su cargo; no se atribuyen como realizadas.
# Parte 3: version con sorteos directos
Fecha: 21/11/2026. Rama existente Fede.

## Solicitud y alcance
Fede renombro la version anterior como Parte 3 v2 y dejo Parte 3 vacia. Solicita otra version que cubra la letra, basada en las clases y usando Discrete_Random, sin organizarla para cambios hipoteticos de defensa. Se crearon unicamente Fede/Parte 3/torneo.adb y verificar.py. Todos los archivos de Parte 3 v2 conservan su contenido: hashes SHA-256 comparados antes/despues. No hubo cambios de rama ni commits ni PDF.

## Fuentes y decisiones
Letra Infraestructura Obligatorio Agosto 2026 (1).pdf, paginas 9-11: ocho partidos definidos entre 16 parejas, tres canchas como tasks, Coordinador, citas para solicitar y devolver resultados, duracion aleatoria hasta cuatro segundos, ganadores aleatorios, exclusividad de asignacion y cancha y cierre tras los ocho resultados. La pagina 14 admite bibliotecas no dadas en clase exigiendo solvencia.
Material de clase/8. ADA (1) (1).pdf: diapositivas 11,14,18 para paquetes; 22 para entry/accept; 27 para select; 37 para task type; 45 para trabajo fuera de las citas. Apuntes del 09/11, secciones 4-6, y 10/11, secciones 5-6, para tareas, llamadas, esperas y terminacion implicita. Fuentes consultadas en esta misma conversacion. Las clases del 16/11 y 17/11 revisadas previamente no cambian este ejercicio.
Manual de referencia Ada A.5.2, https://www.adaic.org/resources/add_content/standards/12rm/html/RM-A-5-2.html , para Discrete_Random. El paquete concreto es una decision autorizada por Fede, no una herramienta atribuida al docente.

## Implementacion
Se conserva el protocolo de Coordinador y tres tasks Cancha porque corresponde a la letra. La cancha solicita un partido mediante Solicitar_Partido y espera el accept. El Coordinador es el unico que modifica los pendientes y resultados y devuelve el numero por out. Cero indica fin, no un partido adicional. select permite recibir solicitud o resultado sin imponer una alternancia fija.
La cancha sortea directamente la duracion con Azar_Duracion.Random, imprime el inicio y demora con delay Duration(Duracion), fuera de la cita. Luego sortea directamente entre las dos parejas con Azar_Ganador.Random e if. Informa al Coordinador por Informar_Resultado y espera su recepcion antes de pedir otro partido.
No se incorporan Elegir_Duracion, Elegir_Ganador, modos sin azar, unidad de tiempo configurable ni pruebas de modificaciones hipoteticas. Hay comentarios didacticos sobre las esperas, el select, la propiedad del estado y el cierre conforme a AGENTS.md.
El Coordinador distingue asignados de terminados y responde fin a cada cancha libre; sigue disponible para quienes estan jugando. Al responder fin a las tres, ya recibio los ocho resultados. El bloque declare espera que terminen todas las tareas antes de imprimir Torneo terminado. Las assertions comprueban consistencia y no reemplazan la sincronizacion.

## Discrete_Random
Es un paquete estandar que se instancia con un rango discreto. Usamos 0-4 para segundos y 1-2 para elegir la pareja A o B del encuentro. Cada cancha tiene un Generator para cada rango. Reset inicializa cada generador una sola vez usando una inicializacion dependiente del tiempo; Random obtiene el siguiente valor y actualiza su estado. Los generadores son propios de cada cancha y no requieren sincronizar estado compartido. Son secuencias pseudoaleatorias, no azar fisico; dos Reset proximos no garantizan secuencias diferentes.
No se duplico el Markdown explicativo por instruccion de Fede. Su explicacion conceptual sigue vigente, pero el apartado sobre las dos funciones auxiliares y los cambios hipoteticos corresponde exclusivamente a la v2 y no describe el codigo nuevo.

## Pruebas ejecutadas
Entorno autorizado: mi_ubuntu, GNAT 13.3.0 y Python 3, sin instalar paquetes ni modificar archivos existentes. Carpeta temporal propia /tmp/infra-fede-parte3-directa-20261121.
Comandos:
- docker exec mi_ubuntu mkdir /tmp/infra-fede-parte3-directa-20261121
- docker cp "Fede/Parte 3/." mi_ubuntu:/tmp/infra-fede-parte3-directa-20261121/
- docker exec mi_ubuntu python3 /tmp/infra-fede-parte3-directa-20261121/verificar.py
El verificador compila con gnatmake -q -f -gnat2012 -gnatwa -gnatwe -gnata -gnato: sin advertencias ni errores. La version rapida cambia solo el delay en una copia temporal a una centesima; no altera la fuente entregada ni elimina azar. Tambien compila y ejecuta la fuente original dos veces con tiempos reales.
Resultados:
- 20 ejecuciones rapidas correctas: ocho asignaciones y resultados unicos, pertenecientes a la cancha y parejas correspondientes, ninguna cancha usada por dos partidos a la vez, informe antes de siguiente solicitud, cierre de tres canchas y anuncio final despues de todas las tasks.
- Hasta tres canchas en paralelo; 19 distribuciones de partidos entre canchas; todos los valores de duracion 0-4 observados.
- Dos ejecuciones reales correctas: ocho resultados y tres canchas cerradas, hasta tres jugando en ambas. Duraciones observadas primera 0,2,3,4; segunda 1,2,3,4.
- Hashes de Parte 3 v2 sin cambios y git diff --check correcto.
No se hicieron variantes de defensa. Las pruebas aportan evidencia de varios entrelazados, no una demostracion exhaustiva; se complemento con revision del protocolo y del cierre. El verificador Python no es dependencia de la simulacion. Para compilar en Linux: gnatmake -gnat2012 -gnata torneo.adb; ejecutar ./torneo.
La carpeta temporal del contenedor se retiro al terminar. Queda revision humana y puesta en comun para elegir entre versiones; documentacion general de entrega al final.

## Uso de IA
Codex, modelo GPT-6 segun contexto: cambio de organizacion solicitado, verificador, pruebas y reporte. No se atribuye revision humana ni autoria docente de esta propuesta.

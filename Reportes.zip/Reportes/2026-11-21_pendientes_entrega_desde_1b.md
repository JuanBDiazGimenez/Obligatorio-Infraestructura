# Inventario de pendientes de entrega desde Parte 1b

21/11/2026. Solicitud: revisar lo existente en Fede y distinguir faltantes de entrega, sin evaluar la corrección de las soluciones. Consulta de estado Git sin diferencias pendientes; no se modificó código ni se ejecutaron pruebas.

## Fuentes consultadas

Infraestructura Obligatorio Agosto 2026 (1).pdf: páginas 3-5 (1b y documentación), 7-8 (Parte 2), 9-11 (Parte 3), 12-13 (entregables de Parte 4), 1 (declaración de IA y condiciones) y 16 (archivo de entrega y PDF). Se inventariaron los archivos de Fede con rg --files. Se leyó implementacion_parte1b.md y se extrajo el texto de su PDF; se consultaron README.md de Parte 4 y Discrete_Random.md de Parte 3. El instructivo de Parte 4 fue producido y revisado visualmente en la instancia anterior; no se volvió a generar.

## Estado por parte

1b: están don_drones.sh, flota.csv, implementacion_parte1b.pdf con conceptos relevantes y ejemplo completo, y el instructivo de pruebas. usuarios.csv se genera al arrancar, según la documentación: su ausencia en la carpeta no constituye por sí sola un archivo faltante de distribución. No se detecta un documento obligatorio pendiente desde el inventario.

2: ambas versiones tienen main.c, pruebas y PDF de instrucciones. La letra no exige expresamente un informe de implementación separado ni capturas como entregables de esta parte. Falta seleccionar una versión para la propuesta definitiva del grupo, no desarrollar otra prestación por este inventario.

3: ambas versiones tienen torneo.adb, verificador, explicación Markdown de Discrete_Random y PDF de instrucciones. La letra no exige expresamente un informe adicional específico de esta parte. Falta elegir una versión para la entrega. Si se incluye la explicación Markdown como documentación final, debe incorporarse a un PDF; no es obligatorio entregar ese archivo didáctico como documento separado.

4: están las fuentes Ada, Dockerfile, Compose, instructivo PDF y evidencia textual. La explicación de la comunicación está en README.md. Falta llevar esa explicación al PDF de documentación de entrega, ya sea propio o general. Conviene incorporar una selección identificada de las trazas guardadas al mismo documento, con explicación de qué muestra cada una; la evidencia ya existe, no se declara necesario generar una nueva ejecución o capturas de pantalla. Los .txt originales son trazas, no archivos usados para comunicarse.

## Cierre de la entrega

- Seleccionar versiones definitivas de 2 y 3 con el grupo y reunir las partes elegidas en una carpeta final comprensible. Los nombres v2 y las comparaciones son materiales de decisión, no un requisito para entregar duplicados.
- Preparar una declaración de uso de IA que cubra el conjunto, herramientas y contexto. Existen menciones en 1b y README de 4, pero no se encontró en Fede un documento final que cubra 2 y 3. Se puede integrar en la documentación general; no se exige un PDF independiente por cada parte.
- Documentos de texto finales en PDF. README y explicaciones didácticas pueden servir de fuente; no asumir que todos los reportes internos deben integrar la entrega. Los fuentes .sh, .c, .adb/.ads, CSV y Dockerfile/Compose conservan sus formatos funcionales.
- Armar y comprobar el archivo único ZIP/RAR, máximo 40 MB según el recordatorio de página 16. No se encontró ese paquete en Fede. No se creó ahora.
- El test Redis-Ada y los PDFs de comparación no están exigidos como entregables. Decidir su inclusión es una tarea de selección, no un faltante de implementación.

Fuera del alcance desde 1b: la integración de 1a con el trabajo de la compañera. No se evaluó su corrección ni su estado final.

La letra contiene contradicciones administrativas: cantidad de integrantes (página 1 frente a 16) y fecha de defensa. No se fijan aquí como definitivas ni se inventa una aclaración. Las condiciones actuales deben confirmarse con la información oficial del curso antes de la presentación; no afectan este inventario técnico.

No se concluye que el código sea correcto: solo se constató presencia de archivos y cobertura documental de los entregables. Las explicaciones internas de estudio y los elementos valorados en la defensa no se convierten en requisitos de informes adicionales que la letra no enumera.

Uso de IA: Codex, GPT-6 según contexto de sesión, para inventario y contraste documental. No se atribuyen pruebas nuevas ni revisión humana del grupo.
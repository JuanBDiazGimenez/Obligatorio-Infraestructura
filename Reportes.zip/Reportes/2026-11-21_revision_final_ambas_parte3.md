# Revision de ambas versiones de Parte 3
Fecha: 21/11/2026. Rama Fede. Solicitud: determinar si ambas implementaciones pueden considerarse terminadas. No se modifico codigo ni documentacion existente.

## Fuentes y revision
Letra Infraestructura Obligatorio Agosto 2026 (1).pdf, paginas 9-11 y rubrica de Ada pagina 14, releidas. Se revisaron torneo.adb de Parte 3 y Parte 3 v2, sus verificadores y Discrete_Random.md de la version directa. Material docente ya contrastado en la implementacion: 8. ADA (1) (1).pdf, diapositivas 22,27,37,45; apuntes 09/11 y 10/11 sobre tareas, citas, select y terminacion implicita.
Ambas versiones contienen ocho partidos iniciales para dieciseis parejas, una task Coordinador y tres instancias de task Cancha. Solicitud y resultado se realizan por citas. Los pendientes y resultados solo los modifica el Coordinador; una cancha espera a informar antes de solicitar otro partido, impidiendo doble ocupacion. Las demoras ocurren fuera de accept y permiten jugar concurrentemente. Duracion aleatoria 0-4 y ganador entre las dos parejas. En v2 Unidad_Tiempo permanece 1.0.
No hay cierre prematuro tras la octava asignacion: el Coordinador responde fin a cada cancha solo cuando solicita libre, tras informar su ultimo resultado; sigue recibiendo resultados de las otras. Tras las tres respuestas de fin se recibieron ocho resultados. El bloque padre espera todas las tareas antes de anunciar Torneo terminado. No se detecto ciclo de espera en el protocolo normal. Ninguna task llama al Coordinador despues de haber recibido fin.
La rubrica no prohibe el paquete estandar autorizado por Fede; exige poder explicar su utilizacion. Las funciones auxiliares de v2 no alteran requisitos funcionales.

## Verificacion ejecutada de nuevo
Se crearon copias en /tmp/infra-revision-ambas3-20261121/directa y /tmp/infra-revision-ambas3-20261121/v2 dentro del contenedor autorizado mi_ubuntu. Se ejecuto python3 verificar.py de cada copia. GNAT compila con -gnat2012 -gnatwa -gnatwe -gnata -gnato; los verificadores exigen salida sin advertencias/errores y aplican timeout a cada simulacion.
Parte 3: veinte ejecuciones rapidas correctas, veinte distribuciones de partidos observadas y valores 0-4. Dos ejecuciones con tiempos reales correctas, duraciones observadas 1,2,3,4 y 0,1,2. En ambas hasta tres canchas jugando, ocho resultados unicos y tres tareas de cancha finalizadas.
Parte 3 v2: veinte ejecuciones rapidas correctas, diecinueve distribuciones y valores 0-4. Sus dos pruebas adicionales sin azar tambien correctas, sin modificar las fuentes de trabajo. Dos ejecuciones con tiempos reales correctas, valores observados 0,1,2,4 en ambas, hasta tres canchas jugando, ocho resultados y cierre de las tres.
Los verificadores comprobaron asignaciones y resultados unicos, parejas validas, correspondencia de cancha, ausencia de superposicion de partidos por cancha, recepcion antes de siguiente solicitud, tiempos en rango y anuncio final despues de cerrar todas las tareas. git diff --check sin problemas.
Solo se retiraron las copias temporales de esta revision en el contenedor. No se instalaron dependencias ni se modificaron otros recursos. No se hicieron commits ni nuevos PDFs.

## Conclusion y pendiente concreto
Ambas versiones pueden considerarse completas en implementacion y verificacion para la letra revisada. No se identificaron fallos funcionales que requieran cambios. Las ejecuciones no demuestran todos los entrelazados posibles; se complemento con lectura del mecanismo de coordinacion y cierre.
Pendiente documental: Fede/Parte 3/Discrete_Random.md, lineas 31-32 y seccion de cambios en defensa, menciona Elegir_Duracion y Elegir_Ganador, que solo existen en Parte 3 v2. La explicacion conceptual es valida, pero esas referencias deben adaptarse antes de usar ese archivo para describir la version directa. No se cambio el Markdown durante esta revision.
Para la entrega global queda elegir la version en la puesta en comun, integrar la documentacion y revisar los comentarios didacticos temporales conforme a AGENTS.md. Eso no implica funcionalidad pendiente del torneo.

## Uso de IA
Codex, GPT-6 segun contexto: revision por lectura, contraste de letra, ejecucion de verificadores y reporte. Revision humana del equipo no atribuida.
